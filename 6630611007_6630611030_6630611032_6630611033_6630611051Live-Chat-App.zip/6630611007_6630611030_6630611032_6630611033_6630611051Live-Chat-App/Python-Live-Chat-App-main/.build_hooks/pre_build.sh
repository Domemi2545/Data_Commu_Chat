#!/bin/bash
set -e

echo "Installing build dependencies..."
apt-get update
apt-get install -y build-essential python3-dev